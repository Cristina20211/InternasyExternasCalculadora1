package com.example.laboratorio2

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    private var etn_Nombre: TextView? = null
    private var etn_Edad: TextView? = null
    private var etn_Departamento: TextView?=null
    //private var btn_agregar: Button?=null

    private val Nombres = arrayOf("Kotlin ", "Java", "C++", "C#", "PHP", "VB.net")
    private val Edad = arrayOf("1", "6", "3", "2", "4", "5")
    private val Departamento = arrayOf("La union", "La Palma", "Sonsonate", "La libertad")



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.listviewapp)


        etn_Nombre = findViewById(R.id.etn_Nombre)
        etn_Edad = findViewById(R.id.etn_Edad)

        var adaptador: ArrayAdapter<String> = ArrayAdapter<String>(this, R.layout.listviewapp)
           // etn_Nombre?.adapter = adaptador


            //etn_Nombre?.onItemClickListener = object : AdapterView.OnItemClickListener{
            //override fun onItemClick(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
               // etn_Nombre?.text="La posicion ${etn_Nombre?.getItemAtPosition(position)} es ${posicion[position]}"
            }
        }

   // }





