package com.example.laboratorio2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
   var etn_Nombre:EditText?=null
    //lateinit var  etn_Nombre:EditText
   lateinit var etn_Edad:EditText
   lateinit var etn_Departamento:EditText
   lateinit var btn_agregar:Button
  lateinit var TextView:TextView





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       etn_Nombre = findViewById(R.id.etn_Nombre)
        etn_Edad=findViewById(R.id.etn_Edad)
        etn_Departamento=findViewById(R.id.etn_Departamento)
        btn_agregar=findViewById(R.id.btn_agregar)
        TextView=findViewById(R.id.textView)

        

    }

    fun  btn_agregar ( Vista: View){
        //val  btn_agregar:Intent=Intent()

        val ListView: Intent = Intent(applicationContext,MainActivity::class.java)
        startActivity(ListView)

    }
}